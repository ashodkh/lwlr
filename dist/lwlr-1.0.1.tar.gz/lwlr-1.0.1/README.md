# Local Weighted Linear Regression (lwlr)
This is a package for local linear regression. The usage_example notebook illustrates how to use it.

# Installation
```
pip install lwlr
```
# Importing
```
from lwlr import LWLR
```
**Dependencies**
- Python >= 3.6
- sklearn
- numpy
