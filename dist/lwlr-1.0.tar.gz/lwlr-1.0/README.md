# Local Linear Regression (LLR)
This is a package for local linear regression. I have explained what is LLR and how to implement it at https://github.com/ashod1/Machine-Learning-Methods/blob/main/document.pdf.

# Installation
```
git clone https://github.com/ashod1/LLR-package
cd pypackbasics
pip install .
```
**Dependencies**
- Python >= 3.6
- sklearn
- numpy
